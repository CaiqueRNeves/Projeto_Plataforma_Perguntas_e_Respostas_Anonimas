const sequelize = require("sequelize");

const connection = new sequelize("guiadeperguntas","root","Caique-0408",{
    host: "localhost",
    dialect: "mysql"
});

module.exports = connection;