const Sequelize = require("sequelize");
const connection = require("./database");

const PerguntaBD = connection.define("pergunta",{
    titulo:{
        type:Sequelize.STRING,
        allowNull: false
    },
    descricao:{
        type: Sequelize.TEXT,
        allowNull: false
    }
});

PerguntaBD.sync({force: false}).then(() => {});

module.exports = PerguntaBD;