const express = require("express");
const app = express();
const bodyparser = require("body-parser");
const connection = require("./database/database");
const PerguntaBD = require("./database/PerguntaBD");
const Resposta = require("./database/Resposta");
const { where } = require("sequelize");
//Model é uma representação da sua tabela no código Javascript.
//estou dizendo ao express, para utilizar o ejs como view engine, como renderizador de html.
app.set('view engine', 'ejs');
//Os arquivos html, devem ser salvos em uma pasta chamada 'views'.
//Os arquivos html devem ser salvos dentro da pasta views, com a extensão ".ejs".
app.use(express.static('public'));
//Uma pasta chamada 'public' foi criada aqui,para armazenar todo tipo de arquivo estático.
//Uma pasta chamada 'css' foi criada para armazenar o arquivo para estilização do frontend.
//Arquivos estáticos são arquivos que não são processados pelo backend, como arquivos css, js do frontend, imagens, etc.
app.use(bodyparser.urlencoded({extended: false}));
//Este comando permite que um usuário consiga enviar dados de um formulário, e o body parser traduza esses dados em uma estrutura javascript para que se possa utilizar dentro do projeto.
app.use(bodyparser.json());
//Este comando permite com que consigamos ler dados de formulários enviados via Json.(Utilizaremos quando estivermos trabalhando com API's)

//Database
//Database connection
connection.authenticate()
     .then(() => {
        console.log("conexão realizada com sucesso!");
     })
     .catch((msgErro) => {
        console.log(msgErro); 
     })
//Eu vou tentar me autenticar no meu banco, com a minha conexão "database.js", caso seja bem sucedida, quem será usado será o ".then", se não, será executado o catch.
//A estrutura acima é chamada de promisse.

//Aqui abaixo estou dizendo para o express usar o EJS como view engine
app.get("/",(req, res) =>{    
    PerguntaBD.findAll({raw: true, order:[
        ['id', 'DESC'] //Aqui estou ordenando que as perguntas sempre fiquem na ordem decrescente, ou seja, do maior id para o menor.
    ]}).then(perguntas => {
        res.render("index", {
            perguntas: perguntas
        });
    });
    
});

app.get("/perguntas",(req,res) => {
    res.render("perguntas");
})

app.get("/cadastro",(req,res) => {
    res.render("cadastro");
})

app.get("/assuntosmaiscomentados",(req,res) => {
    res.render("assuntosmaiscomentados");
})

app.post("/salvarpergunta",(req,res) => {
    var titulo = req.body.titulo;
    var descricao = req.body.descricao;
    PerguntaBD.create({
        titulo: titulo,
        descricao: descricao
    }).then(() => {
        res.redirect("/");
    });

});

app.get("/pergunta/:id", (req,res) => {
    var id = req.params.id;
    PerguntaBD.findOne({
        where: {id:id}
    }).then(pergunta => {
        if(pergunta != undefined){
            Resposta.findAll({
                where: {perguntaId: pergunta.id},
                order: [['id', 'DESC']]
            }).then(respostas => {
                res.render("pergunta",{
                    pergunta: pergunta,
                    respostas: respostas
                });
            });            
        } else {
            res.redirect("/");
        }
    });
});

app.post("/responder", (req,res) => {
    var corpo = req.body.corpo;
    var perguntaId = req.body.pergunta;
    Resposta.create({
        corpo: corpo,
        perguntaId: perguntaId
    }).then(() => {
        res.redirect("/pergunta/" + perguntaId);
    });
});

app.listen(8080,()=>{console.log("App rodando!");});